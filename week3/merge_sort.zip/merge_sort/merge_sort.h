#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include <cstddef>
#include <vector>

void mergeSort(std::vector<int> &a, std::size_t l, std::size_t r);

#endif  // MERGE_SORT_H
