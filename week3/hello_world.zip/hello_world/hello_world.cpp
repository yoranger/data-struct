#include <cstdlib>
#include <iostream>

int main() {
  // TODO: Print "Hello, World!" to the console, followed by a newline.

  return EXIT_SUCCESS;
}
