#include "ListNode.h"

// Constructor (don't change this)
ListNode::ListNode(int x) : val(x), next(nullptr) {}

ListNode* reverseList(ListNode* head) {
    // YOUR CODE GOES HERE
    // HINT: You may want to use three pointers for this problem: prev, curr, and next
}