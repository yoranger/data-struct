// CPP program to implement Queue using
// two stacks with costly deQueue()
#include <stack>
#include "queue_using_2_stacks.h"
using namespace std;

Queue::Queue()
{
	// Constructor (don't change this)
}

void Queue::enqueue(int x)
{
    // How would you use the two stacks s1 and s2 to implement enqueue?
    // YOUR CODE GOES HERE
}

int Queue::dequeue()
{
    // How would you use the two stacks s1 and s2 to implement dequeue?
    // HINT 1: Use one stack to hold the incoming items
    // HINT 2: Use the other stack to hold the outgoing items
    // HINT 3: You may need to move items between the two stacks
    // YOUR CODE GOES HERE
}