#include <unordered_map>
#include <vector>

int findMajority(std::vector<int>& nums) {
    // YOUR CODE GOES HERE
 }