#ifndef MAJORITY_H
#define MAJORITY_H

#include <unordered_map>
#include <vector>

int findMajority(std::vector<int>& nums);

#endif