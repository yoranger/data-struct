#include "image_segmentation.h"

// TODO:
// Implement imageMSTCost using an MST algorithm (Prim's or Kruskal's).
// Hint:
//   - Treat each pixel as a node.
//   - Connect 4-neighbour pixels (up, down, left, right) with edge weights
//     equal to |intensity_u - intensity_v|.
//   - Run an MST algorithm on this graph and return the sum of weights of
//     all edges in the MST.
//
// You do NOT need to actually output the segmentation here; just compute
// the MST total "dissimilarity" cost of the image.

int imageMSTCost(int rows, int cols, const vector<int> &pixels) {
  // Replace this stub with your implementation.
  // For now, return 0 so the file compiles.
  (void)rows;
  (void)cols;
  (void)pixels;
  return 0;
}

