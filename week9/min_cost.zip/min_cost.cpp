#include "min_cost.h"

#include <vector>
// TODO: Add any necessary libraries here and in min_cost.h

using namespace std;

int distance(vector<int> &p1, vector<int> &p2) {
  return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]);
}

int minCost(vector<vector<int>> &points) {
  // Hint: Model the problem as a complete graph where each pair of points
  // is connected by an edge with weight equal to their Manhattan distance,
  // then use an MST algorithm (Prim's or Kruskal's) to compute the minimum
  // total cost to connect all points.
}
