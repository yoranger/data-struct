#include "game_pathfinding.h"

#include <climits>
#include <queue>
#include <vector>

using namespace std;

int shortestPathCost(int rows, int cols, const vector<vector<int>> &terrain,
                     int start_r, int start_c, int target_r, int target_c) {
  // TODO: Implement Bellman-Ford algorithm
  //
  // Steps:
  // 1. Convert 2D positions to 1D indices: idx = row * cols + col
  // 2. Initialize distances: start cell = terrain[start_r][start_c], others =
  // INT_MAX
  // 3. Use Bellman-Ford (relaxation iterations)
  // 4. Handle 4-directional movement (up, down, left, right)
  // 5. Return the shortest path cost to target

  // Stub implementation - replace with your algorithm
  return 0;
}
