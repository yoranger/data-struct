#ifndef MOBILE_GAME_PROGRESSION_RECURSIVE_H
#define MOBILE_GAME_PROGRESSION_RECURSIVE_H

int calculateProgressionPaths(int n);

#endif
