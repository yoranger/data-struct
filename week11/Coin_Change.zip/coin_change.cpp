#include <vector>

int coinChange(std::vector<int>& coins, int amount){
    // YOUR CODE HERE
}