# include <string>

int longestCommonSubsequence(std::string dna1, std::string dna2) {
    // YOUR CODE HERE
    return 0; // Placeholder return value
}