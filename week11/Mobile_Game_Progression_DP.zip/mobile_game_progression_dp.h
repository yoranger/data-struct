#ifndef MOBILE_GAME_PROGRESSION_DP_H
#define MOBILE_GAME_PROGRESSION_DP_H

int calculateProgressionPathsDP(int n);

#endif